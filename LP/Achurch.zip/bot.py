from __future__ import annotations
from antlr4 import *
from exprsLexer import exprsLexer
from exprsParser import exprsParser
from exprsVisitor import exprsVisitor
from dataclasses import dataclass

from telegram.ext import Updater,CommandHandler
from telegram.ext import MessageHandler, Filters

import pydot

#Per obrir el token
TOKEN = open('token.txt').read().strip()
updater = Updater(token=TOKEN, use_context=True)


#Classes de lambda calcul
@dataclass
class Var:
      var: str
          
@dataclass
class App:
      terme1: Terme
      terme2: Terme
            
@dataclass
class Abs:
      var: str
      terme: Terme
      
Terme = Var | App | Abs

#Funcio per crear l'arbre donat una expressio
def create_tree(expression: Terme, graph: pydot.Dot, abstraction=None, id_gen=None):
    if id_gen is None:
        id_gen = iter(range(1000000))
    if isinstance(expression, Var):
        node = pydot.Node(name = next(id_gen), label = expression.var)
        graph.add_node(node)
        if (abstraction != None):
            d = (str(abstraction).split("\""))[1]
            de = d[1]
            if str(expression.var) == str(de):
                graph.add_edge(pydot.Edge(node,abstraction, style='dashed'))
        return node
    elif isinstance(expression, App):
        node = pydot.Node(name = next(id_gen), label = '@')
        graph.add_node(node)
        left = create_tree(expression.terme1, graph, abstraction, id_gen)
        right = create_tree(expression.terme2, graph, abstraction, id_gen)
        graph.add_edge(pydot.Edge(node, left))
        graph.add_edge(pydot.Edge(node, right))
        return node
    elif isinstance(expression, Abs):
        node = pydot.Node(name = next(id_gen), label = f'λ{expression.var}')
        graph.add_node(node)
        child = create_tree(expression.terme, graph, node, id_gen)
        graph.add_edge(pydot.Edge(node, child))
        return node

def get_bound_variables(expression):
    return {str(expression.var)}

#Funcio d'alpha conversio, donat una expressio, subtitueix les old_var per el new_var
def alpha_convert(expression, old_var, new_var):
    if isinstance(expression, Var):
        return Var(new_var) if str(expression.var) == str(old_var) else expression
    elif isinstance(expression, App):
        return App(alpha_convert(expression.terme1, old_var, new_var), alpha_convert(expression.terme2, old_var, new_var))
    elif isinstance(expression, Abs):
        if str(expression.var) == str(old_var):
            return Abs(new_var, alpha_convert(expression.terme, old_var, new_var))
        else:
            return Abs(expression.var, alpha_convert(expression.terme, old_var, new_var))
    else:
        return expression
    
#Funcio que donat una terme | expressio et retorna una variable que no estigui repetida en la expressio
def get_fresh_variable(terme):
    used_variables = get_free_variables(terme)
    for i in range(1, 26):
        var = chr(ord('a') + i)
        if var not in used_variables:
            return var
    raise Exception("No fresh variable available")

#Funcio que retorna les variables lliures del terme
def get_free_variables(terme):
    if isinstance(terme, Var):
        return {str(terme.var)}
    elif isinstance(terme, App):
        return get_free_variables(terme.terme1) | get_free_variables(terme.terme2)
    else:
        return get_free_variables(terme.terme) - {str(terme.var)}
    
#Funcio de beta reduccio
def beta_reduction(expr: Terme, max_steps: int, update,context):
    if max_steps <= 0:
        return "Nothing"
    if isinstance(expr, Var):
        return expr
    elif isinstance(expr, Abs):
        return Abs(expr.var, beta_reduction(expr.terme,max_steps - 1,update,context))
    elif isinstance(expr, App):
        if isinstance(expr.terme1, Abs):
            new_expr = substitute(expr.terme1.terme, expr.terme1.var, expr.terme2)
            context.bot.send_message(chat_id=update.message.chat_id, text=("β-reducció:")) 
            context.bot.send_message(chat_id=update.message.chat_id, text=str((show(expr)+ " → "+show(new_expr)))) 
            return beta_reduction(new_expr,max_steps - 1,update,context)
        else:
            return App(beta_reduction(expr.terme1,max_steps - 1,update,context), beta_reduction(expr.terme2,max_steps - 1,update,context))
    else:
        return expr
#Funcio per determinar si una expressio te conflicte amb les variables, es a dir, si es necessita aplica un alpha conversio
def has_name_conflict(expr: Terme, letter, update,context ):

    if isinstance(expr, Abs):
        new_bound_vars = get_bound_variables(expr)
        
        if (  letter in new_bound_vars):
            new_l = str(get_fresh_variable(expr))
            context.bot.send_message(chat_id=update.message.chat_id, text=str(("α-conversió: "+ letter + " → " + new_l))) 
            aux = alpha_convert(expr,str(expr.var),new_l)
            return aux
        else:
            return Abs(str(expr.var),has_name_conflict(expr.terme, letter, update,context))
    elif isinstance(expr, App):
        return App(has_name_conflict(expr.terme1, letter, update,context),has_name_conflict(expr.terme2, letter, update,context))
    else:
        return expr
#Funcio per sustituir les variables aplicant en les beta reduccions
def substitute(expression, variable, value):
    if isinstance(expression, Var):
        """if isinstance(variable,Var):
            if (expression.var == variable.var):
                return value
            else: 
                return expression
        else:"""
        aux1 = str(expression.var)
        aux2 = str(variable)
        if (aux1 == aux2):
                return value
        else: 
                return expression
    
    elif isinstance(expression, App):
        return App(substitute(expression.terme1, variable, value), substitute(expression.terme2, variable, value))
    
    elif isinstance(expression, Abs):
        if expression.var == variable:
            return expression
        else:
            return Abs(expression.var, substitute(expression.terme, variable, value))
    else:
        return expression

#Classe del evaluator
class EvalVisitor(exprsVisitor):
    def __init__(self):
        self.variable={}
        
    def visitRoot(self, ctx):
        expressio = list(ctx.getChildren())
        return self.visit(expressio[0])
        #print(self.visit(expressio)) 

    def visitAplicacio(self, ctx):
        [t1,t2] = list(ctx.getChildren())
        aux = App(self.visit(t1), self.visit(t2))
        return aux
    
    def visitMacro(self, ctx):
        [l] = list(ctx.getChildren())
        if (l.getText() in self.variable.keys()):
            return self.variable[l.getText()]
        else: return None
    
    def visitTerm(self, ctx):
        [p1,t,p2] = list(ctx.getChildren())
        return self.visit(t)
    
    def visitLletra(self, ctx):
        [var] = list(ctx.getChildren())
        aux = Var(var)
        return aux
    
    def visitLletres(self, ctx):
        lv =  list(ctx.getChildren())
        return lv
        
    def visitAbstraccio(self, ctx):
        [l, v, p, t] = list(ctx.getChildren())
        lv = self.visit(v)
        lv.reverse()
        abs = Abs(lv[0],self.visit(t))
        lv.pop(0)
        for v in lv:
            abs = Abs(v,abs)
        return abs
    
    def visitMacroInf(self, ctx):
        [t1,inf,t2] = list(ctx.getChildren())
        return App(App(self.variable[inf.getText()],self.visit(t1)),self.visit(t2))
    
    def visitAssign(self, ctx):
        [name,e,exp] = list(ctx.getChildren())
        self.variable[name.getText()] = self.visit(exp)
        return name.getText()

#Funcio per poder mostrar les expressions en forma "d'arbre"
def show(a: Terme) -> str:
    match a:
        case Abs(x,t):
            return '(' + 'λ' + str(x) + '.'  +  show(t) + ')'
        case App(t1,t2):
            return '(' + show(t1) + show(t2) + ')'
        case Var(x):
            return  str(x)
#Funcio per determinar si una expressio donada es correcte o no    
def isNone(a: Terme):
    match a:
        case Abs(x,t):
            return (x == None) and isNone(t)
        case App(t1,t2):
            return isNone(t1) and isNone(t2)
        case Var(x):
            return  (x == None)
#Funcio auxiliar per avaluar el nombre maxim de iteracions de beta reduccions
def aux_evaluate(auxiliar,update,context):
    while True:
        reduced = beta_reduction(auxiliar,20,update,context)
        if auxiliar == reduced:
            return reduced
        elif reduced == "Nothing":
            return "Nothing"
        auxiliar = reduced

#Funcio per avaluar una expressio
def evaluate(expression,update,context):
    context.bot.send_message(chat_id=update.message.chat_id, text="Arbre:") 
    context.bot.send_message(chat_id=update.message.chat_id, text=show(expression)) 
    
    graph = pydot.Dot(graph_type='digraph',strict=True)
    create_tree(expression, graph)
    graph.write_png('lambda_expression.png')
    
    context.bot.send_photo(chat_id=update.message.chat_id, \
         photo=open('lambda_expression.png', 'rb'))    
    
    auxiliar = expression
    
    if (maybe_needs_alpha_conversion(expression)):
        new_expresion = has_name_conflict(expression,str(expression.terme2.var),update,context)
        
        if (new_expresion != expression):
            context.bot.send_message(chat_id=update.message.chat_id, text=str(show(expression)+" → " +show(new_expresion))) 
            auxiliar = new_expresion
    
    reduced = aux_evaluate(auxiliar,update,context)

    context.bot.send_message(chat_id=update.message.chat_id, text=("Resultat:"))
    if  reduced == "Nothing":
        context.bot.send_message(chat_id=update.message.chat_id, text="Nothing") 
    else:
        context.bot.send_message(chat_id=update.message.chat_id, text=show(reduced))
        graph = pydot.Dot(graph_type='digraph',strict=True)
        create_tree(reduced, graph)
        graph.write_png('lambda_expression.png')
        
        context.bot.send_photo(chat_id=update.message.chat_id, \
            photo=open('lambda_expression.png', 'rb'))   

#Funcio per determinar si es necessita una alpha conversio
def maybe_needs_alpha_conversion(t: Terme):
    if isinstance(t, App):
        if isinstance(t.terme2, Var):
            return True
        else:
            return False
    else:
        return False
    
#Funcio per escriure els macros
def write_macros(variables_macros):
    for key,value in variables_macros.items():
        return (key, '≡', show(value))

evalu= EvalVisitor()

# defineix una funció que saluda i que s'executarà quan el bot rebi el missatge /start
def start(update, context):
    context.bot.send_message(chat_id=update.message.chat_id, text="AChurchBot\nBenvingut Haonan!")

updater.dispatcher.add_handler(CommandHandler('start', start))

# defineix una funció que mostra un misstage de help
def help(update, context):
    context.bot.send_message(chat_id=update.message.chat_id, text="/start\n/author\n/help\n/macros\nExpressió λ-càlcul")

updater.dispatcher.add_handler(CommandHandler('help', help))

# defineix una funció que mostra l'autor del programa
def author(update, context):
    context.bot.send_message(chat_id=update.message.chat_id, text="AChurchBot\n/@ Haonan Jin, 2023")

updater.dispatcher.add_handler(CommandHandler('author', author))

# defineix una funció mostra tots els macros introduïts
def macros(update, context):
    variables_ma = evalu.variable
    for key,value in variables_ma.items():
        context.bot.send_message(chat_id=update.message.chat_id, text=str(key+ '≡'+show(value))) 

updater.dispatcher.add_handler(CommandHandler('macros', macros))

#Funcio principal
def calc(update, context):
    msg = update.message.text
    input_stream = InputStream(msg)

    lexer = exprsLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = exprsParser(token_stream)
    tree = parser.root()
    
    aux = evalu.visit(tree)

    if not isinstance(aux,str):
        if not (isNone(aux) == None):
            evaluate(aux,update,context)
        else:
            context.bot.send_message(chat_id=update.message.chat_id, text="El teu input es incorrecte")
    

updater.dispatcher.add_handler(MessageHandler(Filters.text, calc))

# engega el bot
updater.start_polling()

    
    

