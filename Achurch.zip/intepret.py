from __future__ import annotations
from antlr4 import *
from exprsLexer import exprsLexer
from exprsParser import exprsParser
from exprsVisitor import exprsVisitor
from dataclasses import dataclass


@dataclass
class Var:
      var: str
          
@dataclass
class App:
      terme1: Terme
      terme2: Terme
            
@dataclass
class Abs:
      var: str
      terme: Terme
      
Terme = Var | App | Abs


def get_bound_variables(expression):

    return {str(expression.var)}

    
#Funcio d'alpha conversio, donat una expressio, subtitueix les old_var per el new_varss
def alpha_convert(expression, old_var, new_var):
    if isinstance(expression, Var):
        return Var(new_var) if str(expression.var) == str(old_var) else expression
    elif isinstance(expression, App):
        return App(alpha_convert(expression.terme1, old_var, new_var), alpha_convert(expression.terme2, old_var, new_var))
    elif isinstance(expression, Abs):
        if str(expression.var) == str(old_var):
            return Abs(new_var, alpha_convert(expression.terme, old_var, new_var))
        else:
            return Abs(expression.var, alpha_convert(expression.terme, old_var, new_var))
    else:
        return expression
    
#Funcio que donat una terme | expressio et retorna una variable que no estigui repetida en la expressio    
def get_fresh_variable(terme):
    used_variables = get_free_variables(terme)
    for i in range(1, 26):
        var = chr(ord('a') + i)
        if var not in used_variables:
            return var
    raise Exception("No fresh variable available")

#Funcio que retorna les variables lliures del terme
def get_free_variables(terme):
    if isinstance(terme, Var):
        return {str(terme.var)}
    elif isinstance(terme, App):
        return get_free_variables(terme.terme1) | get_free_variables(terme.terme2)
    else:
        return get_free_variables(terme.terme) - {str(terme.var)}
        

#Funcio de beta reduccio    
def beta_reduction(expr: Terme, max_steps: int) -> Terme:
    if max_steps <= 0:
        return "Nothing"
    if isinstance(expr, Var):
        return expr
    elif isinstance(expr, Abs):
        return Abs(expr.var, beta_reduction(expr.terme,max_steps - 1))
    elif isinstance(expr, App):
        if isinstance(expr.terme1, Abs):
            new_expr = substitute(expr.terme1.terme, expr.terme1.var, expr.terme2)
            print("β-reducció:")
            print(show(expr), " → ",show(new_expr))
            return beta_reduction(new_expr,max_steps - 1)
        else:
            return App(beta_reduction(expr.terme1,max_steps - 1), beta_reduction(expr.terme2,max_steps - 1))
    else:
        return expr
#Funcio per determinar si una expressio te conflicte amb les variables, es a dir, si es necessita aplica un alpha conversio    
def has_name_conflict(expr: Terme, letter ):

    if isinstance(expr, Abs):
        new_bound_vars = get_bound_variables(expr)
        
        if (  letter in new_bound_vars):
            new_l = str(get_fresh_variable(expr))
            print ("α-conversió: ", letter, " → ", new_l)
            aux = alpha_convert(expr,str(expr.var),new_l)
            return aux
        else:
            return Abs(str(expr.var),has_name_conflict(expr.terme, letter))
    elif isinstance(expr, App):
        return App(has_name_conflict(expr.terme1, letter),has_name_conflict(expr.terme2, letter))
    else:
        return expr
    
#Funcio per sustituir les variables aplicant en les beta reduccions    
def substitute(expression, variable, value):
    if isinstance(expression, Var):
        """if isinstance(variable,Var):
            if (expression.var == variable.var):
                return value
            else: 
                return expression
        else:"""
        aux1 = str(expression.var)
        aux2 = str(variable)
        if (aux1 == aux2):
                return value
        else: 
                return expression
    
    elif isinstance(expression, App):
        return App(substitute(expression.terme1, variable, value), substitute(expression.terme2, variable, value))
    
    elif isinstance(expression, Abs):
        if expression.var == variable:
            return expression
        else:
            return Abs(expression.var, substitute(expression.terme, variable, value))
    else:
        return expression

#Classe del evaluator
class EvalVisitor(exprsVisitor):
    def __init__(self):
        self.variable={}
        
    def visitRoot(self, ctx):
        expressio = list(ctx.getChildren())
        return self.visit(expressio[0])
        #print(self.visit(expressio)) 

    def visitAplicacio(self, ctx):
        [t1,t2] = list(ctx.getChildren())
        aux = App(self.visit(t1), self.visit(t2))
        return aux
    
    def visitMacro(self, ctx):
        [l] = list(ctx.getChildren())
        if (l.getText() in self.variable.keys()):
            return self.variable[l.getText()]
        else: return None
    
    def visitTerm(self, ctx):
        [p1,t,p2] = list(ctx.getChildren())
        return self.visit(t)
    
    def visitLletra(self, ctx):
        [var] = list(ctx.getChildren())
        aux = Var(var)
        return aux
    
    def visitLletres(self, ctx):
        lv =  list(ctx.getChildren())
        return lv
        
    def visitAbstraccio(self, ctx):
        [l, v, p, t] = list(ctx.getChildren())
        lv = self.visit(v)
        lv.reverse()
        abs = Abs(lv[0],self.visit(t))
        lv.pop(0)
        for v in lv:
            abs = Abs(v,abs)
        return abs
    
    def visitMacroInf(self, ctx):
        [t1,inf,t2] = list(ctx.getChildren())
        return App(App(self.variable[inf.getText()],self.visit(t1)),self.visit(t2))
    
    def visitAssign(self, ctx):
        [name,e,exp] = list(ctx.getChildren())
        self.variable[name.getText()] = self.visit(exp)
        return name.getText()
    
#Funcio per poder mostrar les expressions en forma "d'arbre"    
def show(a: Terme) -> str:
    match a:
        case Abs(x,t):
            return '(' + 'λ' + str(x) + '.'  +  show(t) + ')'
        case App(t1,t2):
            return '(' + show(t1) + show(t2) + ')'
        case Var(x):
            return  str(x)
#Funcio per determinar si una expressio donada es correcte o no    
def isNone(a: Terme):
    match a:
        case Abs(x,t):
            return (x == None) and isNone(t)
        case App(t1,t2):
            return isNone(t1) and isNone(t2)
        case Var(x):
            return  (x == None)
#Funcio auxiliar per avaluar el nombre maxim de iteracions de beta reduccions        
def aux_evaluate(auxiliar):
    while True:
        reduced = beta_reduction(auxiliar,20)
        if auxiliar == reduced:
            return reduced
        elif reduced == "Nothing":
            return "Nothing"
        auxiliar = reduced
#Funcio per avaluar una expressio
def evaluate(expression):
    print ("Arbre:")
    print (show(expression))
    auxiliar = expression
    
    if (maybe_needs_alpha_conversion(expression)):
        new_expresion = has_name_conflict(expression,str(expression.terme2.var))
        
        if (new_expresion != expression):
            print (show(expression)," → " ,show(new_expresion))
            auxiliar = new_expresion
    
    reduced = aux_evaluate(auxiliar)

    print ("Resultat:")
    if  reduced == "Nothing":
        print ("Nothing")
    else:
        print (show(reduced))  

#Funcio per determinar si es necessita una alpha conversio
def maybe_needs_alpha_conversion(t: Terme):
    if isinstance(t, App):
        if isinstance(t.terme2, Var):
            return True
        else:
            return False
    else:
        return False
    
#Funcio per escriure els macros    
def write_macros(variables_macros):
    for key,value in variables_macros.items():
        print (key, '≡', show(value))

evalu= EvalVisitor()
while (True):
    input_stream = InputStream(input('? '))
    
    lexer = exprsLexer(input_stream)
    token_stream = CommonTokenStream(lexer)
    parser = exprsParser(token_stream)
    tree = parser.root()
    #print(tree.toStringTree(recog=parser))
    #visitor = TreeVisitor()
    #visitor.visit(tree) 
    
    aux = evalu.visit(tree)
    variables_ma = evalu.variable

    if isinstance(aux,str):
        write_macros(variables_ma)
    else:
        if not (isNone(aux) == None):
            evaluate(aux)
        else:
            print("El teu input es incorrecte")
    

    

    
    

